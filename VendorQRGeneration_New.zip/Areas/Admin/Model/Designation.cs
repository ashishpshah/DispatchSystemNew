﻿namespace Dispatch_System
{
	public class Designation
	{
		public long Id { get; set; }
		public long Plant_Id { get; set; }
		public string Name { get; set; }
		public string Plant_Name { get; set; }
		public bool IsActive { get; set; }
	}
}
