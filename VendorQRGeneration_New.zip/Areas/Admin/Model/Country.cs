﻿namespace Dispatch_System
{
    public class Country
    {
        public long CountryId { get;  set; }
        public string Country_Name { get; set; }
        public string Code { get; set; }
        public bool IsActive { get; set; }
    }
}
