﻿namespace Dispatch_System
{
    public class State
    {
       

        public long Id { get; set; }
        public long CountryId { get; set; }
        public string State_Name { get; set; }
        public string State_Code { get; set; }
        public bool IsActive { get; set; }
		public string Country_Name { get; set; }

	}
}
