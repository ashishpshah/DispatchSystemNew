﻿namespace Dispatch_System
{
	public class Transport
	{
		public string tptr_cd { get; set; }
		public string tptr_name { get; set; }
		public bool IS_ENTRY_MANUAL { get; set; }
		public int plant_Id { get; set; }
		public bool IS_POSTED { get; set; }
		public int Id { get; set; }
		public bool IsActive { get; set; }
	}
}
