﻿namespace Dispatch_System
{ 
	public class Url
	{
		public string url { get; set; }
		public string url_name { get; set; }
		public string menu_name { get; set; }
		public int menu_id { get; set; }
		public int Id { get; internal set; }
	}
}
